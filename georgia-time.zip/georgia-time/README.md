# Hora Georgia (EUA) vs CDMX

Servicio que consulta la hora actual de **Georgia, EUA** (zona `America/New_York`, Eastern Time)
y calcula la diferencia de horario con **Ciudad de México** (`America/Mexico_City`).
Cada consulta se guarda en **MongoDB**.

| Capa      | Tecnología                         | Puerto |
|-----------|------------------------------------|--------|
| Frontend  | Angular 18 + Nginx                 | 4300   |
| Backend   | Java 21 + Spring Boot 3.3          | 8080   |
| Base de datos | MongoDB 7                      | 27017  |

## Levantar todo

```bash
docker compose up --build
```

Abre http://localhost:4300

## API

- `GET /api/time/georgia` → hora actual en Georgia y CDMX, diferencia en horas (guarda la consulta).
- `GET /api/time/history` → últimas 20 consultas guardadas.

Ejemplo de respuesta:

```json
{
  "id": "6731...",
  "queriedAt": "2026-11-11T02:42:43Z",
  "georgiaTime": "2026-11-10 21:42:43",
  "georgiaZone": "America/New_York",
  "georgiaOffset": "UTC-05:00",
  "georgiaDst": false,
  "cdmxTime": "2026-11-10 20:42:43",
  "cdmxZone": "America/Mexico_City",
  "cdmxOffset": "UTC-06:00",
  "differenceHours": 1.0,
  "description": "Georgia va 1 hora adelante de CDMX"
}
```

## Cómo se calcula

Se usa la base de datos de zonas horarias IANA incluida en Java (`java.time`), sin depender de APIs externas.
La diferencia cambia en el año:

- **Invierno** (EST, UTC-5): Georgia va **1 hora** adelante de CDMX.
- **Verano** (EDT, UTC-4, de marzo a noviembre): Georgia va **2 horas** adelante.
  México ya no aplica horario de verano desde 2022 (CDMX siempre UTC-6).

## Desarrollo local (sin Docker)

```bash
# MongoDB
docker compose up -d mongodb

# Backend
cd backend && mvn spring-boot:run

# Frontend (usa proxy.conf.json para redirigir /api a :8080)
cd frontend && npm install && npm start
```

## Ver los datos en MongoDB

```bash
docker exec -it georgia-mongodb mongosh timezonedb --eval "db.time_queries.find().sort({queriedAt:-1}).limit(5)"
```

## Cambiar puertos

Si algún puerto está ocupado, cámbialo con variables de entorno (o en un archivo `.env` junto al `docker-compose.yml`):

```bash
FRONTEND_PORT=4500 BACKEND_PORT=8081 MONGO_PORT=27018 docker compose up --build
```
