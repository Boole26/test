package com.thinkboole.timezone.repository;

import com.thinkboole.timezone.model.TimeQuery;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface TimeQueryRepository extends MongoRepository<TimeQuery, String> {
    List<TimeQuery> findTop20ByOrderByQueriedAtDesc();
}
