package com.thinkboole.timezone.controller;

import com.thinkboole.timezone.model.TimeQuery;
import com.thinkboole.timezone.service.TimeService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/time")
public class TimeController {

    private final TimeService service;

    public TimeController(TimeService service) {
        this.service = service;
    }

    /** Consulta la hora actual de Georgia y la diferencia con CDMX (y la guarda en MongoDB). */
    @GetMapping("/georgia")
    public TimeQuery georgia() {
        return service.queryNow();
    }

    /** Últimas 20 consultas guardadas. */
    @GetMapping("/history")
    public List<TimeQuery> history() {
        return service.history();
    }
}
