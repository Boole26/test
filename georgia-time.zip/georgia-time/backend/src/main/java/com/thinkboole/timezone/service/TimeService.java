package com.thinkboole.timezone.service;

import com.thinkboole.timezone.model.TimeQuery;
import com.thinkboole.timezone.repository.TimeQueryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class TimeService {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final TimeQueryRepository repository;
    private final ZoneId georgiaZone;
    private final ZoneId cdmxZone;
    private final Clock clock;

    @Autowired
    public TimeService(TimeQueryRepository repository,
                       @Value("${app.zones.georgia}") String georgia,
                       @Value("${app.zones.cdmx}") String cdmx) {
        this(repository, ZoneId.of(georgia), ZoneId.of(cdmx), Clock.systemUTC());
    }

    TimeService(TimeQueryRepository repository, ZoneId georgiaZone, ZoneId cdmxZone, Clock clock) {
        this.repository = repository;
        this.georgiaZone = georgiaZone;
        this.cdmxZone = cdmxZone;
        this.clock = clock;
    }

    /** Calcula la hora actual en Georgia y CDMX, la diferencia, y guarda la consulta. */
    public TimeQuery queryNow() {
        TimeQuery q = calculate(Instant.now(clock));
        return repository.save(q);
    }

    public List<TimeQuery> history() {
        return repository.findTop20ByOrderByQueriedAtDesc();
    }

    TimeQuery calculate(Instant now) {
        ZonedDateTime ga = now.atZone(georgiaZone);
        ZonedDateTime mx = now.atZone(cdmxZone);

        int gaSeconds = ga.getOffset().getTotalSeconds();
        int mxSeconds = mx.getOffset().getTotalSeconds();
        double diff = (gaSeconds - mxSeconds) / 3600.0;

        TimeQuery q = new TimeQuery();
        q.setQueriedAt(now);
        q.setGeorgiaTime(ga.format(FMT));
        q.setGeorgiaZone(georgiaZone.getId());
        q.setGeorgiaOffset("UTC" + ga.getOffset().getId().replace("Z", "+00:00"));
        q.setGeorgiaDst(georgiaZone.getRules().isDaylightSavings(now));
        q.setCdmxTime(mx.format(FMT));
        q.setCdmxZone(cdmxZone.getId());
        q.setCdmxOffset("UTC" + mx.getOffset().getId().replace("Z", "+00:00"));
        q.setDifferenceHours(diff);
        q.setDescription(describe(diff));
        return q;
    }

    private String describe(double diff) {
        if (diff == 0) return "Georgia y CDMX tienen la misma hora";
        String hours = (Math.abs(diff) % 1 == 0)
                ? String.valueOf((long) Math.abs(diff))
                : String.valueOf(Math.abs(diff));
        String unit = Math.abs(diff) == 1 ? "hora" : "horas";
        return diff > 0
                ? "Georgia va " + hours + " " + unit + " adelante de CDMX"
                : "Georgia va " + hours + " " + unit + " atrás de CDMX";
    }
}
