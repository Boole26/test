package com.thinkboole.timezone.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

/** Registro de cada consulta guardado en MongoDB (colección "time_queries"). */
@Document(collection = "time_queries")
public class TimeQuery {

    @Id
    private String id;
    private Instant queriedAt;
    private String georgiaTime;
    private String georgiaZone;
    private String georgiaOffset;
    private boolean georgiaDst;
    private String cdmxTime;
    private String cdmxZone;
    private String cdmxOffset;
    private double differenceHours;
    private String description;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public Instant getQueriedAt() { return queriedAt; }
    public void setQueriedAt(Instant queriedAt) { this.queriedAt = queriedAt; }
    public String getGeorgiaTime() { return georgiaTime; }
    public void setGeorgiaTime(String georgiaTime) { this.georgiaTime = georgiaTime; }
    public String getGeorgiaZone() { return georgiaZone; }
    public void setGeorgiaZone(String georgiaZone) { this.georgiaZone = georgiaZone; }
    public String getGeorgiaOffset() { return georgiaOffset; }
    public void setGeorgiaOffset(String georgiaOffset) { this.georgiaOffset = georgiaOffset; }
    public boolean isGeorgiaDst() { return georgiaDst; }
    public void setGeorgiaDst(boolean georgiaDst) { this.georgiaDst = georgiaDst; }
    public String getCdmxTime() { return cdmxTime; }
    public void setCdmxTime(String cdmxTime) { this.cdmxTime = cdmxTime; }
    public String getCdmxZone() { return cdmxZone; }
    public void setCdmxZone(String cdmxZone) { this.cdmxZone = cdmxZone; }
    public String getCdmxOffset() { return cdmxOffset; }
    public void setCdmxOffset(String cdmxOffset) { this.cdmxOffset = cdmxOffset; }
    public double getDifferenceHours() { return differenceHours; }
    public void setDifferenceHours(double differenceHours) { this.differenceHours = differenceHours; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
