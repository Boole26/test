package com.thinkboole.timezone.service;

import com.thinkboole.timezone.model.TimeQuery;
import org.junit.jupiter.api.Test;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;

import static org.junit.jupiter.api.Assertions.*;

class TimeServiceTest {

    private final TimeService service = new TimeService(null,
            ZoneId.of("America/New_York"), ZoneId.of("America/Mexico_City"), Clock.systemUTC());

    @Test
    void invierno_unaHoraDeDiferencia() {
        TimeQuery q = service.calculate(Instant.parse("2026-01-15T18:00:00Z"));
        assertEquals(1.0, q.getDifferenceHours());
        assertEquals("2026-01-15 13:00:00", q.getGeorgiaTime());
        assertEquals("2026-01-15 12:00:00", q.getCdmxTime());
        assertFalse(q.isGeorgiaDst());
    }

    @Test
    void verano_dosHorasDeDiferencia() {
        // México ya no aplica horario de verano (desde 2022); EUA sí.
        TimeQuery q = service.calculate(Instant.parse("2026-07-15T18:00:00Z"));
        assertEquals(2.0, q.getDifferenceHours());
        assertTrue(q.isGeorgiaDst());
        assertEquals("Georgia va 2 horas adelante de CDMX", q.getDescription());
    }
}
