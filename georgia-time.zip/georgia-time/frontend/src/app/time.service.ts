import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface TimeQuery {
  id: string;
  queriedAt: string;
  georgiaTime: string;
  georgiaZone: string;
  georgiaOffset: string;
  georgiaDst: boolean;
  cdmxTime: string;
  cdmxZone: string;
  cdmxOffset: string;
  differenceHours: number;
  description: string;
}

@Injectable({ providedIn: 'root' })
export class TimeService {
  private http = inject(HttpClient);
  private base = '/api/time';

  consultar(): Observable<TimeQuery> {
    return this.http.get<TimeQuery>(`${this.base}/georgia`);
  }

  historial(): Observable<TimeQuery[]> {
    return this.http.get<TimeQuery[]>(`${this.base}/history`);
  }
}
