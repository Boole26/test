import { Component, OnInit, inject, signal } from '@angular/core';
import { DatePipe, DecimalPipe } from '@angular/common';
import { TimeQuery, TimeService } from './time.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [DatePipe, DecimalPipe],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  private api = inject(TimeService);

  actual = signal<TimeQuery | null>(null);
  historial = signal<TimeQuery[]>([]);
  cargando = signal(false);
  error = signal<string | null>(null);

  ngOnInit(): void {
    this.consultar();
  }

  consultar(): void {
    this.cargando.set(true);
    this.error.set(null);
    this.api.consultar().subscribe({
      next: r => {
        this.actual.set(r);
        this.cargando.set(false);
        this.cargarHistorial();
      },
      error: () => {
        this.error.set('No se pudo consultar el backend. ¿Está corriendo?');
        this.cargando.set(false);
      }
    });
  }

  cargarHistorial(): void {
    this.api.historial().subscribe({ next: h => this.historial.set(h) });
  }

  hora(fecha: string): string {
    return fecha.split(' ')[1] ?? fecha;
  }
}
